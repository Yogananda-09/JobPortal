package com.nemesis.JobAppPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobAppPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
